// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:notespace_home_screen/home_app.dart';

void main() {
  runApp(HomeApp());
}
